import React from 'react';
import NewsList from './components/NewsList';

function App() {
  return (
    <div className="bg-gray-100 min-h-screen">
      <NewsList />
    </div>
  );
}

export default App;